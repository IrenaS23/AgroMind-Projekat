# AgroMind - AI-powered Farming Assistant

AgroMind is a smart AI assistant that helps you manage your farming activities.

## Features

- 🏠 **Home Page**: Welcome screen and quick start
- 🔐 **Authentication**: Secure login and registration system
- 💬 **AgroChatbot**: AI chatbot that answers your questions about agriculture
- 📒 **AgroJournal**: Record and track your farming activities
- 📊 **Analytics**: Yield, cost and profit analysis with charts

## Installation

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

3. Open `http://localhost:5173` in your browser.

## Technologies Used

- React 18
- React Router DOM
- Recharts (For charts)
- Vite (Build tool)
- CSS3 (Modern responsive design)

## Pages

- `/` - Home page
- `/auth` - Login and registration page
- `/dashboard/chatbot` - Chatbot page
- `/dashboard/journal` - Journal entry page
- `/dashboard/analytics` - Analytics page

## Design

Modern, responsive design with green and earthy tones. All pages work perfectly on desktop and mobile devices.

## Deployment

This project is configured for Vercel deployment. The build command is `npm run build` and the output directory is `dist`.
