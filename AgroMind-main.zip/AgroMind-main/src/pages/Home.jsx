import { Link } from 'react-router-dom'
import './Home.css'

function Home() {
  return (
    <div className="home">
      <div className="hero-section">
        <div className="hero-overlay">
          <div className="hero-content">
            <h1 className="hero-title">Welcome to AgroMind</h1>
            <p className="hero-subtitle">Your AI-powered farming assistant</p>
            <Link to="/auth" className="get-started-btn">
              Get Started
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home

