import { Outlet, useNavigate, useLocation } from 'react-router-dom'
import './Dashboard.css'

function Dashboard({ onLogout }) {
  const navigate = useNavigate()
  const location = useLocation()

  const handleLogout = () => {
    onLogout()
    navigate('/')
  }

  const isActive = (path) => {
    return (
      location.pathname === `/dashboard/${path}` ||
      (path === 'chatbot' && location.pathname === '/dashboard')
    )
  }

  return (
    <div className="dashboard">
      <aside className="sidebar">
        <div className="sidebar-header">
          <h2>🌾 AgroMind</h2>
        </div>
        <nav className="sidebar-nav">
          <button
            className={`nav-item ${isActive('chatbot') ? 'active' : ''}`}
            onClick={() => navigate('/dashboard/chatbot')}
          >
            <span className="nav-icon">💬</span>
            <span className="nav-text">AgroChatbot</span>
          </button>

          <button
            className={`nav-item ${isActive('journal') ? 'active' : ''}`}
            onClick={() => navigate('/dashboard/journal')}
          >
            <span className="nav-icon">📒</span>
            <span className="nav-text">AgroJournal</span>
          </button>

          <button
            className={`nav-item ${isActive('analytics') ? 'active' : ''}`}
            onClick={() => navigate('/dashboard/analytics')}
          >
            <span className="nav-icon">📊</span>
            <span className="nav-text">Analytics</span>
          </button>

          {/* 🔥 DODAJ OVAJ NOVI DIO */}
          <button
            className={`nav-item ${isActive('vision') ? 'active' : ''}`}
            onClick={() => navigate('/dashboard/vision')}
          >
            <span className="nav-icon">🌾</span>
            <span className="nav-text">AI Image Analysis</span>
          </button>
        </nav>

        <div className="sidebar-footer">
          <button className="logout-btn" onClick={handleLogout}>
            Logout
          </button>
        </div>
      </aside>

      <main className="dashboard-main">
        <Outlet />
      </main>
    </div>
  )
}

export default Dashboard
