import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Auth.css";

function Auth({ onLogin }) {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    if (formData.email && formData.password) {
      onLogin();
      navigate("/dashboard");
    }
  };

  const handleRegisterSubmit = (e) => {
    e.preventDefault();
    if (
      formData.fullName &&
      formData.email &&
      formData.password &&
      formData.password === formData.confirmPassword
    ) {
      onLogin();
      navigate("/dashboard");
    } else if (formData.password !== formData.confirmPassword) {
      alert("Passwords do not match!");
    }
  };

  return (
    <div className="auth-page">
      <div className="login-glass-card">
        <h2 className="auth-title">
          {isLogin ? "Welcome Back to AgroMind" : "Create an AgroMind Account"}
        </h2>
        <p className="auth-subtitle">
          {isLogin
            ? "Sign in to continue managing your smart farming data."
            : "Register to get started with smart agriculture insights."}
        </p>

        <form
          onSubmit={isLogin ? handleLoginSubmit : handleRegisterSubmit}
          className="auth-form"
        >
          {!isLogin && (
            <div className="form-group">
              <input
                type="text"
                name="fullName"
                placeholder="Full Name"
                value={formData.fullName}
                onChange={handleChange}
                required
              />
            </div>
          )}

          <div className="form-group">
            <input
              type="email"
              name="email"
              placeholder="Email"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={formData.password}
              onChange={handleChange}
              required
            />
          </div>

          {!isLogin && (
            <div className="form-group">
              <input
                type="password"
                name="confirmPassword"
                placeholder="Confirm Password"
                value={formData.confirmPassword}
                onChange={handleChange}
                required
              />
            </div>
          )}

          <button type="submit" className="auth-button">
            {isLogin ? "Login" : "Create Account"}
          </button>
        </form>

        <p className="auth-switch">
          {isLogin ? "Don’t have an account?" : "Already have an account?"}{" "}
          <span className="toggle" onClick={() => setIsLogin(!isLogin)}>
            {isLogin ? "Register" : "Login"}
          </span>
        </p>
      </div>
    </div>
  );
}

export default Auth;
