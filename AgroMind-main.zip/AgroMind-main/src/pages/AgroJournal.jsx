import { useState, useEffect } from "react";
import "./AgroJournal.css";

function AgroJournal() {
  const [entries, setEntries] = useState([]);
  const [formData, setFormData] = useState({
    cropName: "",
    datePlanted: "",
    fertilizationDate: "",
    sprayingDate: "",
    totalYield: "",
    cost: "",
    profit: "",
    image: null,
  });
  const [showForm, setShowForm] = useState(false);
  const [temperature, setTemperature] = useState("");
  const [reminder, setReminder] = useState("");
  const [alert, setAlert] = useState(null);

  const handleChange = (e) => {
    if (e.target.type === "file") {
      setFormData({
        ...formData,
        image: e.target.files[0],
      });
    } else {
      setFormData({
        ...formData,
        [e.target.name]: e.target.value,
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newEntry = {
      id: Date.now(),
      ...formData,
      imageUrl: formData.image ? URL.createObjectURL(formData.image) : null,
    };
    setEntries([...entries, newEntry]);
    setFormData({
      cropName: "",
      datePlanted: "",
      fertilizationDate: "",
      sprayingDate: "",
      totalYield: "",
      cost: "",
      profit: "",
      image: null,
    });
    setShowForm(false);
  };

  const handleDelete = (id) => {
    setEntries(entries.filter((entry) => entry.id !== id));
  };

  const showAIAlert = (message, type = "info") => {
    setAlert({ message, type });
    setTimeout(() => setAlert(null), 4000); // alert nestaje nakon 4 sekunde
  };

  const checkReminder = () => {
    if (!temperature) {
      setReminder("🌤️ Unesite trenutnu temperaturu kako bi AI dao preporuku!");
      return;
    }

    if (temperature > 30) {
      const msg = "🔥 AI upozorenje: Visoka temperatura! Zalijte biljke i provjerite vlagu zemljišta.";
      setReminder(msg);
      showAIAlert(msg, "warning");
    } else if (temperature < 10) {
      const msg = "❄️ AI upozorenje: Niske temperature! Preporučuje se zaštita biljaka od mraza.";
      setReminder(msg);
      showAIAlert(msg, "error");
    } else {
      const msg = "✅ AI kaže: Uslovi su optimalni za rast biljaka.";
      setReminder(msg);
      showAIAlert(msg, "success");
    }
  };

  return (
    <div className="journal-container">
      {alert && (
        <div className={`ai-alert ${alert.type}`}>
          <p>{alert.message}</p>
        </div>
      )}

      <div className="journal-header">
        <h1>📒 AgroJournal</h1>
        <p>Record and track your farming activities</p>
        <button className="add-entry-btn" onClick={() => setShowForm(!showForm)}>
          {showForm ? "Close Form" : "+ Add New Entry"}
        </button>
      </div>

      {showForm && (
        <form className="journal-form" onSubmit={handleSubmit}>
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="cropName">Crop Name *</label>
              <input
                type="text"
                id="cropName"
                name="cropName"
                value={formData.cropName}
                onChange={handleChange}
                required
                placeholder="e.g. Mandarin, Olive"
              />
            </div>

            <div className="form-group">
              <label htmlFor="datePlanted">Date Planted</label>
              <input
                type="date"
                id="datePlanted"
                name="datePlanted"
                value={formData.datePlanted}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="fertilizationDate">Fertilization Date</label>
              <input
                type="date"
                id="fertilizationDate"
                name="fertilizationDate"
                value={formData.fertilizationDate}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label htmlFor="sprayingDate">Spraying Date</label>
              <input
                type="date"
                id="sprayingDate"
                name="sprayingDate"
                value={formData.sprayingDate}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="totalYield">Total Yield (kg)</label>
              <input
                type="number"
                id="totalYield"
                name="totalYield"
                value={formData.totalYield}
                onChange={handleChange}
                placeholder="0"
                min="0"
                step="0.01"
              />
            </div>

            <div className="form-group">
              <label htmlFor="cost">Cost ($)</label>
              <input
                type="number"
                id="cost"
                name="cost"
                value={formData.cost}
                onChange={handleChange}
                placeholder="0"
                min="0"
                step="0.01"
              />
            </div>

            <div className="form-group">
              <label htmlFor="profit">Profit ($)</label>
              <input
                type="number"
                id="profit"
                name="profit"
                value={formData.profit}
                onChange={handleChange}
                placeholder="0"
                step="0.01"
              />
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="image">Crop Image</label>
            <input
              type="file"
              id="image"
              name="image"
              accept="image/*"
              onChange={handleChange}
            />
          </div>

          <button type="submit" className="submit-btn">
            Save
          </button>
        </form>
      )}

      <div className="ai-reminder-section">
        <h3>🤖 AI Reminder</h3>
        <p>Enter the current temperature to get a smart tip for your crops:</p>
        <div className="reminder-box">
          <input
            type="number"
            placeholder="Temperature °C"
            value={temperature}
            onChange={(e) => setTemperature(e.target.value)}
          />
          <button onClick={checkReminder}>Check</button>
        </div>
        {reminder && <div className="reminder-message">{reminder}</div>}
      </div>

      <div className="entries-section">
        <h2>Entries ({entries.length})</h2>
        {entries.length === 0 ? (
          <div className="empty-state">
            <p>No entries yet. Add your first entry!</p>
          </div>
        ) : (
          <div className="entries-grid">
            {entries.map((entry) => (
              <div key={entry.id} className="entry-card">
                {entry.imageUrl && (
                  <div className="entry-image">
                    <img src={entry.imageUrl} alt={entry.cropName} />
                  </div>
                )}
                <div className="entry-content">
                  <h3>{entry.cropName}</h3>
                  <div className="entry-details">
                    {entry.datePlanted && (
                      <p>
                        <strong>Planted:</strong>{" "}
                        {new Date(entry.datePlanted).toLocaleDateString("en-US")}
                      </p>
                    )}
                    {entry.fertilizationDate && (
                      <p>
                        <strong>Fertilization:</strong>{" "}
                        {new Date(entry.fertilizationDate).toLocaleDateString("en-US")}
                      </p>
                    )}
                    {entry.sprayingDate && (
                      <p>
                        <strong>Spraying:</strong>{" "}
                        {new Date(entry.sprayingDate).toLocaleDateString("en-US")}
                      </p>
                    )}
                    {entry.totalYield && <p><strong>Yield:</strong> {entry.totalYield} kg</p>}
                    {entry.cost && (
                      <p>
                        <strong>Cost:</strong> ${parseFloat(entry.cost).toLocaleString("en-US")}
                      </p>
                    )}
                    {entry.profit && (
                      <p
                        className={
                          parseFloat(entry.profit) >= 0
                            ? "profit-positive"
                            : "profit-negative"
                        }
                      >
                        <strong>Profit:</strong> ${parseFloat(entry.profit).toLocaleString("en-US")}
                      </p>
                    )}
                  </div>
                  <button
                    className="delete-btn"
                    onClick={() => handleDelete(entry.id)}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default AgroJournal;
