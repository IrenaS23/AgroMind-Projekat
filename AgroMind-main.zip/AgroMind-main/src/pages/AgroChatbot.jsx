import { useState, useRef, useEffect } from 'react'
import './AgroChatbot.css'

function AgroChatbot() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: 'Hello! I am your AgroMind assistant. You can ask me questions about agriculture.',
      sender: 'bot'
    }
  ])
  const [inputValue, setInputValue] = useState('')
  const [loading, setLoading] = useState(false)
  const messagesEndRef = useRef(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = async (e) => {
    e.preventDefault()
    if (!inputValue.trim()) return

    // Dodaj korisničku poruku
    const userMessage = {
      id: messages.length + 1,
      text: inputValue,
      sender: 'user'
    }

    setMessages(prev => [...prev, userMessage])
    setInputValue('')
    setLoading(true)

    try {
      // Poziv OpenAI API-ja
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: "You are AgroMind, a friendly assistant helping with agriculture questions." },
            ...messages.map((m) => ({
              role: m.sender === 'user' ? 'user' : 'assistant',
              content: m.text
            })),
            { role: "user", content: inputValue }
          ],
        }),
      });

      const data = await res.json();
      const reply =
        data.choices?.[0]?.message?.content ||
        "Sorry, I couldn't generate a response right now.";

      // Dodaj AI odgovor
      const botMessage = {
        id: messages.length + 2,
        text: reply,
        sender: 'bot'
      };
      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [
        ...prev,
        {
          id: messages.length + 2,
          text: 'Error: Unable to connect to AI service.',
          sender: 'bot'
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="chatbot-container">
      <div className="chatbot-header">
        <h1>💬 AgroChatbot</h1>
        <p>Ask your questions about agriculture, I'm here to help</p>
      </div>

      <div className="chatbot-messages">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`message ${message.sender === 'user' ? 'user-message' : 'bot-message'}`}
          >
            <div className="message-content">{message.text}</div>
          </div>
        ))}

        {loading && (
          <div className="message bot-message">
            <div className="message-content">Typing...</div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <form className="chatbot-input-form" onSubmit={handleSend}>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Type your question..."
          className="chatbot-input"
        />
        <button type="submit" className="chatbot-send-btn" disabled={loading}>
          {loading ? "..." : "Send"}
        </button>
      </form>
    </div>
  )
}

export default AgroChatbot
