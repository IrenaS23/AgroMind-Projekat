import { useState, useMemo } from 'react'
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts'
import './Analytics.css'

// Sample data - in real app, this would come from AgroJournal entries
const sampleData = [
  { month: 'January', yield: 1200, cost: 800, profit: 400 },
  { month: 'February', yield: 1500, cost: 900, profit: 600 },
  { month: 'March', yield: 1800, cost: 1000, profit: 800 },
  { month: 'April', yield: 2000, cost: 1100, profit: 900 },
  { month: 'May', yield: 2200, cost: 1200, profit: 1000 },
  { month: 'June', yield: 2500, cost: 1300, profit: 1200 }
]

const cropData = [
  { name: 'Mandarin', value: 4500 },
  { name: 'Olive', value: 3200 },
  { name: 'Lemon', value: 2800 },
  { name: 'Orange', value: 2100 }
]

const COLORS = ['#228b22', '#32cd32', '#90ee90', '#556b2f']

function Analytics() {
  const [filter, setFilter] = useState('monthly')

  const filteredData = useMemo(() => {
    if (filter === 'weekly') {
      return sampleData.slice(-4).map((item, index) => ({
        ...item,
        month: `Week ${index + 1}`
      }))
    } else if (filter === 'yearly') {
      return [
        { month: '2022', yield: 15000, cost: 9000, profit: 6000 },
        { month: '2023', yield: 18000, cost: 10000, profit: 8000 },
        { month: '2024', yield: 20000, cost: 11000, profit: 9000 }
      ]
    }
    return sampleData
  }, [filter])

  const totalYield = filteredData.reduce((sum, item) => sum + item.yield, 0)
  const totalCost = filteredData.reduce((sum, item) => sum + item.cost, 0)
  const totalProfit = filteredData.reduce((sum, item) => sum + item.profit, 0)
  const mostProfitableCrop = cropData.reduce((max, crop) =>
    crop.value > max.value ? crop : max
  )

  return (
    <div className="analytics-container">
      <div className="analytics-header">
        <h1>📊 Analytics</h1>
        <p>Analysis and insights of your farming activities</p>
        <div className="filter-buttons">
          <button
            className={filter === 'weekly' ? 'active' : ''}
            onClick={() => setFilter('weekly')}
          >
            Weekly
          </button>
          <button
            className={filter === 'monthly' ? 'active' : ''}
            onClick={() => setFilter('monthly')}
          >
            Monthly
          </button>
          <button
            className={filter === 'yearly' ? 'active' : ''}
            onClick={() => setFilter('yearly')}
          >
            Yearly
          </button>
        </div>
      </div>

      <div className="insights-grid">
        <div className="insight-card">
          <div className="insight-icon">🌾</div>
          <div className="insight-content">
            <h3>Total Yield</h3>
            <p className="insight-value">{totalYield.toLocaleString('en-US')} kg</p>
            <span className="insight-label">This {filter === 'weekly' ? 'month' : filter === 'monthly' ? 'year' : 'period'}</span>
          </div>
        </div>

        <div className="insight-card">
          <div className="insight-icon">💰</div>
          <div className="insight-content">
            <h3>Total Cost</h3>
            <p className="insight-value">${totalCost.toLocaleString('en-US')}</p>
            <span className="insight-label">This {filter === 'weekly' ? 'month' : filter === 'monthly' ? 'year' : 'period'}</span>
          </div>
        </div>

        <div className="insight-card">
          <div className="insight-icon">📈</div>
          <div className="insight-content">
            <h3>Total Profit</h3>
            <p className="insight-value profit">${totalProfit.toLocaleString('en-US')}</p>
            <span className="insight-label">This {filter === 'weekly' ? 'month' : filter === 'monthly' ? 'year' : 'period'}</span>
          </div>
        </div>

        <div className="insight-card">
          <div className="insight-icon">🏆</div>
          <div className="insight-content">
            <h3>Most Profitable Crop</h3>
            <p className="insight-value">{mostProfitableCrop.name}</p>
            <span className="insight-label">${mostProfitableCrop.value.toLocaleString('en-US')} profit</span>
          </div>
        </div>
      </div>

      <div className="charts-section">
        <div className="chart-card">
          <h2>Yield, Cost and Profit Analysis</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={filteredData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="yield" stroke="#228b22" strokeWidth={2} name="Yield (kg)" />
              <Line type="monotone" dataKey="cost" stroke="#ff6b6b" strokeWidth={2} name="Cost ($)" />
              <Line type="monotone" dataKey="profit" stroke="#32cd32" strokeWidth={2} name="Profit ($)" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <h2>Yield Distribution by Product</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={filteredData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="yield" fill="#228b22" name="Yield (kg)" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <h2>Profit Distribution by Product</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={cropData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {cropData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}

export default Analytics

