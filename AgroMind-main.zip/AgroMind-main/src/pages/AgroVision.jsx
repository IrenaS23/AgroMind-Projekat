// src/pages/AgroVision.jsx
import { useState } from "react";
import "./AgroVision.css";

export default function AgroVision() {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const onSelectFile = (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!f.type.startsWith("image/")) {
      setError("Please choose an image file.");
      return;
    }
    setError("");
    setFile(f);
    const url = URL.createObjectURL(f);
    setPreview(url);
    setResult("");
  };

  const fileToBase64 = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });

  const analyze = async () => {
    if (!file) return;
    setLoading(true);
    setError("");
    setResult("");

    try {
      const dataUrl = await fileToBase64(file);

      // ⬇️ VAŽNO: za slike koristi gpt-4o / gpt-4o-mini i image_url: { url: ... }
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_OPENAI_API_KEY}`,
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            {
              role: "system",
              content:
                "You are AgroMind Vision, an AI that analyzes plant photos and gives short, practical farming advice.",
            },
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text:
                    "Analyze this plant image. Identify likely issue (disease/pest/deficiency), severity, and give 3 short actionable steps.",
                },
                {
                  type: "image_url",
                  image_url: { url: dataUrl }, // <-- ispravan format
                },
              ],
            },
          ],
          temperature: 0.2,
        }),
      });

      // Ako API vrati grešku, pokaži poruku iz tijela odgovora da znamo tačno zašto
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || `HTTP ${res.status}`);
      }

      const json = await res.json();
      const reply = json?.choices?.[0]?.message?.content || "No result found.";
      setResult(reply);
    } catch (err) {
      console.error(err);
      setError("⚠️ Something went wrong. Check your API key/credits or try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="vision-wrap">
      <div className="vision-card">
        <h2>🌾 AgroVision — AI Image Analysis</h2>
        <p className="sub">
          Upload a photo of your plant or field to analyze its condition.
        </p>

        <div className="upload-box">
          {!preview && (
            <div className="empty-state">
              <p>📷 Upload a photo to begin</p>
            </div>
          )}
          {preview && (
            <div className="preview">
              <img src={preview} alt="preview" />
            </div>
          )}
        </div>

        <div className="uploader">
          <input
            type="file"
            accept="image/*"
            onChange={onSelectFile}
            id="plant-file"
          />
          <label htmlFor="plant-file" className="pick-btn">Choose Image</label>
          <button
            className="analyze-btn"
            onClick={analyze}
            disabled={!file || loading}
          >
            {loading ? "🔍 Analyzing..." : "Analyze"}
          </button>
        </div>

        {error && <div className="error">{error}</div>}

        {result && (
          <div className="result glass">
            <h3>🌱 AI Result</h3>
            <pre>{result}</pre>
          </div>
        )}
      </div>
    </div>
  );
}
