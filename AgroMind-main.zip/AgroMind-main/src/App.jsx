import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import Home from './pages/Home'
import Auth from './pages/Auth'
import Dashboard from './pages/Dashboard'
import AgroChatbot from './pages/AgroChatbot'
import AgroJournal from './pages/AgroJournal'
import Analytics from './pages/Analytics'
import AgroVision from './pages/AgroVision'

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  useEffect(() => {
    // Check if user is logged in from localStorage
    const auth = localStorage.getItem('agromind_auth')
    if (auth) {
      setIsAuthenticated(true)
    }
  }, [])

  const handleLogin = () => {
    setIsAuthenticated(true)
    localStorage.setItem('agromind_auth', 'true')
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    localStorage.removeItem('agromind_auth')
  }

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route 
          path="/auth" 
          element={
            isAuthenticated ? (
              <Navigate to="/dashboard" replace />
            ) : (
              <Auth onLogin={handleLogin} />
            )
          } 
        />
        <Route
          path="/dashboard"
          element={
            isAuthenticated ? (
              <Dashboard onLogout={handleLogout} />
            ) : (
              <Navigate to="/auth" replace />
            )
          }
        >
          <Route index element={<Navigate to="chatbot" replace />} />
          <Route path="chatbot" element={<AgroChatbot />} />
          <Route path="journal" element={<AgroJournal />} />
          <Route path="analytics" element={<Analytics />} />
          <Route path="vision" element={<AgroVision />} />
        </Route>
      </Routes>
    </Router>
  )
}

export default App

